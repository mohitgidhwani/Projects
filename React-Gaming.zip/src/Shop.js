import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function Shop() {
  const [game, setGame] = useState([])
  useEffect(() => {
    fetch('http://localhost:1234/data')
      .then((res) => { return res.json() })
      .then((data) => { setGame(data) })
  }
)



  return (
    <>
      <div>
        <div className="page-heading header-text">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <h3>Our Shop</h3>
                <span className="breadcrumb"><a href="#">Home</a> &gt; Our Shop</span>
              </div>
            </div>
          </div>
        </div>
        <div className="section trending">
          <div className="container">
            <ul className="trending-filter">
              <li>
                <a className="is_active" href="#!" data-filter="*">Show All</a>
              </li>
              <li>
                <a href="#!" data-filter=".adv">Adventure</a>
              </li>
              <li>
                <a href="#!" data-filter=".str">Strategy</a>
              </li>
              <li>
                <a href="#!" data-filter=".rac">Racing</a>
              </li>
            </ul>
            <div className="row trending-box">
              {game.map((games) => {
                return (
                  <>
                    <div key={games.id} className="col-lg-3 col-md-6 align-self-center mb-30 trending-items col-md-6 adv" >
                      <Link to={`/view/${games.id}`}>
                      <div className="item">
                        <div className="thumb">
                          <a href="product-details.html">
                            <img src={games.img} alt="" />
                          </a>
                          <span className="price"><em>{games.cprice}</em>{games.price}</span>
                        </div>
                        <div className="down-content">
                          <span className="category">{games.cat}</span>
                          <h4>{games.name}</h4>
                          <a href="product-details.html"><i className="fa fa-shopping-bag" /></a>
                        </div>
                      </div>
                      </Link>
                    </div>
                  </>
                )
              })}

            </div>
            <div className="row">
              <div className="col-lg-12">
                <ul className="pagination">
                  <li><a href="#"> &lt; </a></li>
                  <li><a href="#">1</a></li>
                  <li><a className="is_active" href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#"> &gt; </a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>



    </>
  )
}

export default Shop