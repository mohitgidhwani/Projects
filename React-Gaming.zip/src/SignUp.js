import React from 'react'
import { Link } from 'react-router-dom'

function SignUp() {
  return (
   <>
   <div>
  <div className="page-heading header-text">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <h3>Register</h3>
          <span className="breadcrumb"><a href="#">Home</a>  &gt;  Contact Us</span>
        </div>
      </div>
    </div>
  </div>
  <div className="contact-page section">
    <div className="container">
      <div className="row justify-content-center">
       
        <div className="col-lg-6">
          <div className="right-content">
            <div className="row">
             
              <div className="col-lg-12">
                <form id="contact-form" method="post">
                  <div className="row">
                    <div className="col-lg-6">
                      <fieldset>
                        <input type="name" name="name" id="name" placeholder="First Name..." autoComplete="on" required />
                      </fieldset>
                    </div>
                    <div className="col-lg-6">
                      <fieldset>
                        <input type="surname" name="surname" id="surname" placeholder="Last Name..." autoComplete="on" required />
                      </fieldset>
                    </div>
                    <div className="col-lg-6">
                      <fieldset>
                        <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..." required />
                      </fieldset>
                    </div>
                    <div className="col-lg-6">
                      <fieldset>
                        <input type="subject" name="subject" id="subject" placeholder="Subject..." autoComplete="on" />
                      </fieldset>
                    </div>
                    <div className="col-lg-12">
                     
                    </div>
                    <div className="col-lg-12">
                      <fieldset>
                        <button type="submit" id="form-submit" className="orange-button d-block m-auto">Register</button>
                      </fieldset>
                      <div className='d-flex justify-content-center pt-5 gap-1'>
                        <span>Back to </span> <Link to={'/sign'} > Sign In</Link>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

   </>
  )
}

export default SignUp