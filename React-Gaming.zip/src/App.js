import logo from './logo.svg';
import './App.css';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import { BrowserRouter, Link, Route, Router, Routes } from 'react-router-dom';
import Shop from './Shop';
import ProductDetails from './ProductDetails';
import Contact from './Contact';
import SignIn from './SignIn';
import SignUp from './SignUp';
import View from './View';


function App() {
  return (
    <div >
      {/* <Header></Header> */}
      {/* <Content></Content> */}
      {/* <Footer></Footer> */}

      <BrowserRouter>
        <Header></Header>
        <Routes>
          <Route path="/" element={<Content></Content>}> </Route>
          <Route path='/shop' element={<Shop></Shop>}></Route>
          <Route path='/product' element={<ProductDetails></ProductDetails>}></Route>
          <Route path='/contact' element={<Contact></Contact>}></Route>
          <Route path='/sign' element={<SignIn></SignIn>}></Route>
          <Route path='/signup' element={<SignUp></SignUp>}></Route>
          <Route path='/view/:id' element={<View></View>}></Route>
        </Routes>
        <Footer></Footer>
      </BrowserRouter>



    </div>
  );
}


export default App;
